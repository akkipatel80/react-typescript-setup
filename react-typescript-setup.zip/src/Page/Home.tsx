import React from "react";

type Props = {};

export default function Home({}: Props) {
  return <div>Home</div>;
}
